﻿using System;
using System.Collections.Generic;

namespace UnrealAPI.Models
{
    public partial class Choices
    {
        public int EntryId { get; set; }
        public string FirstName { get; set; }
        public int? Number { get; set; }
    }
}
