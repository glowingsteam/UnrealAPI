Create Table Choices(
EntryID Int Identity(1,1) Primary Key,
FirstName Varchar(100) Not Null,
Number Int)
GO